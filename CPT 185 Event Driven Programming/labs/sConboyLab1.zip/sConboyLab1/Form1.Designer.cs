﻿namespace sConboyLab1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            exam1Textbox = new TextBox();
            label2 = new Label();
            exam2Textbox = new TextBox();
            label3 = new Label();
            exam3Textbox = new TextBox();
            label4 = new Label();
            exam4Textbox = new TextBox();
            label5 = new Label();
            lab1Textbox = new TextBox();
            label7 = new Label();
            lab2Textbox = new TextBox();
            label8 = new Label();
            lab3Textbox = new TextBox();
            label9 = new Label();
            lab4Textbox = new TextBox();
            label10 = new Label();
            lab5Textbox = new TextBox();
            label11 = new Label();
            quiz1Textbox = new TextBox();
            label12 = new Label();
            quiz2Textbox = new TextBox();
            label13 = new Label();
            quiz3Textbox = new TextBox();
            label14 = new Label();
            quiz4Textbox = new TextBox();
            label15 = new Label();
            quiz5Textbox = new TextBox();
            label16 = new Label();
            calculateScoresButton = new Button();
            toolTip1 = new ToolTip(components);
            closeButton = new Button();
            clearScoresButton = new Button();
            examTotalLabel = new Label();
            examTotalResultLabel = new Label();
            label6 = new Label();
            labTotalResultLabel = new Label();
            quizTotalLabel = new Label();
            quizTotalResultLabel = new Label();
            finalLetterGradeLabel = new Label();
            finalLetterGradeResult = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(293, 51);
            label1.Name = "label1";
            label1.Size = new Size(207, 24);
            label1.TabIndex = 0;
            label1.Text = "Student Grade Report";
            // 
            // exam1Textbox
            // 
            exam1Textbox.Location = new Point(247, 115);
            exam1Textbox.Name = "exam1Textbox";
            exam1Textbox.Size = new Size(45, 22);
            exam1Textbox.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label2.Location = new Point(192, 119);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 0;
            label2.Text = "Exam 1";
            // 
            // exam2Textbox
            // 
            exam2Textbox.Location = new Point(247, 146);
            exam2Textbox.Name = "exam2Textbox";
            exam2Textbox.Size = new Size(45, 22);
            exam2Textbox.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label3.Location = new Point(192, 150);
            label3.Name = "label3";
            label3.Size = new Size(46, 15);
            label3.TabIndex = 2;
            label3.Text = "Exam 2";
            // 
            // exam3Textbox
            // 
            exam3Textbox.Location = new Point(247, 177);
            exam3Textbox.Name = "exam3Textbox";
            exam3Textbox.Size = new Size(45, 22);
            exam3Textbox.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label4.Location = new Point(192, 181);
            label4.Name = "label4";
            label4.Size = new Size(46, 15);
            label4.TabIndex = 4;
            label4.Text = "Exam 3";
            // 
            // exam4Textbox
            // 
            exam4Textbox.Location = new Point(247, 206);
            exam4Textbox.Name = "exam4Textbox";
            exam4Textbox.Size = new Size(45, 22);
            exam4Textbox.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label5.Location = new Point(192, 210);
            label5.Name = "label5";
            label5.Size = new Size(46, 15);
            label5.TabIndex = 6;
            label5.Text = "Exam 4";
            // 
            // lab1Textbox
            // 
            lab1Textbox.Location = new Point(409, 115);
            lab1Textbox.Name = "lab1Textbox";
            lab1Textbox.Size = new Size(45, 22);
            lab1Textbox.TabIndex = 4;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label7.Location = new Point(354, 119);
            label7.Name = "label7";
            label7.Size = new Size(37, 15);
            label7.TabIndex = 10;
            label7.Text = "Lab 1";
            // 
            // lab2Textbox
            // 
            lab2Textbox.Location = new Point(409, 146);
            lab2Textbox.Name = "lab2Textbox";
            lab2Textbox.Size = new Size(45, 22);
            lab2Textbox.TabIndex = 5;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label8.Location = new Point(354, 150);
            label8.Name = "label8";
            label8.Size = new Size(37, 15);
            label8.TabIndex = 12;
            label8.Text = "Lab 2";
            // 
            // lab3Textbox
            // 
            lab3Textbox.Location = new Point(409, 177);
            lab3Textbox.Name = "lab3Textbox";
            lab3Textbox.Size = new Size(45, 22);
            lab3Textbox.TabIndex = 6;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label9.Location = new Point(354, 181);
            label9.Name = "label9";
            label9.Size = new Size(37, 15);
            label9.TabIndex = 14;
            label9.Text = "Lab 3";
            // 
            // lab4Textbox
            // 
            lab4Textbox.Location = new Point(409, 206);
            lab4Textbox.Name = "lab4Textbox";
            lab4Textbox.Size = new Size(45, 22);
            lab4Textbox.TabIndex = 7;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label10.Location = new Point(354, 210);
            label10.Name = "label10";
            label10.Size = new Size(37, 15);
            label10.TabIndex = 16;
            label10.Text = "Lab 4";
            // 
            // lab5Textbox
            // 
            lab5Textbox.Location = new Point(409, 237);
            lab5Textbox.Name = "lab5Textbox";
            lab5Textbox.Size = new Size(45, 22);
            lab5Textbox.TabIndex = 8;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label11.Location = new Point(354, 241);
            label11.Name = "label11";
            label11.Size = new Size(37, 15);
            label11.TabIndex = 18;
            label11.Text = "Lab 5";
            // 
            // quiz1Textbox
            // 
            quiz1Textbox.Location = new Point(572, 115);
            quiz1Textbox.Name = "quiz1Textbox";
            quiz1Textbox.Size = new Size(45, 22);
            quiz1Textbox.TabIndex = 9;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label12.Location = new Point(517, 119);
            label12.Name = "label12";
            label12.Size = new Size(44, 15);
            label12.TabIndex = 20;
            label12.Text = "Quiz 1";
            // 
            // quiz2Textbox
            // 
            quiz2Textbox.Location = new Point(572, 146);
            quiz2Textbox.Name = "quiz2Textbox";
            quiz2Textbox.Size = new Size(45, 22);
            quiz2Textbox.TabIndex = 10;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label13.Location = new Point(517, 150);
            label13.Name = "label13";
            label13.Size = new Size(44, 15);
            label13.TabIndex = 22;
            label13.Text = "Quiz 2";
            // 
            // quiz3Textbox
            // 
            quiz3Textbox.Location = new Point(572, 177);
            quiz3Textbox.Name = "quiz3Textbox";
            quiz3Textbox.Size = new Size(45, 22);
            quiz3Textbox.TabIndex = 11;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label14.Location = new Point(517, 181);
            label14.Name = "label14";
            label14.Size = new Size(44, 15);
            label14.TabIndex = 24;
            label14.Text = "Quiz 3";
            // 
            // quiz4Textbox
            // 
            quiz4Textbox.Location = new Point(572, 206);
            quiz4Textbox.Name = "quiz4Textbox";
            quiz4Textbox.Size = new Size(45, 22);
            quiz4Textbox.TabIndex = 12;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label15.Location = new Point(517, 210);
            label15.Name = "label15";
            label15.Size = new Size(44, 15);
            label15.TabIndex = 26;
            label15.Text = "Quiz 4";
            // 
            // quiz5Textbox
            // 
            quiz5Textbox.Location = new Point(572, 237);
            quiz5Textbox.Name = "quiz5Textbox";
            quiz5Textbox.Size = new Size(45, 22);
            quiz5Textbox.TabIndex = 13;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label16.Location = new Point(517, 241);
            label16.Name = "label16";
            label16.Size = new Size(44, 15);
            label16.TabIndex = 28;
            label16.Text = "Quiz 5";
            // 
            // calculateScoresButton
            // 
            calculateScoresButton.BackColor = Color.White;
            calculateScoresButton.FlatStyle = FlatStyle.System;
            calculateScoresButton.ForeColor = SystemColors.ControlText;
            calculateScoresButton.Location = new Point(338, 284);
            calculateScoresButton.Name = "calculateScoresButton";
            calculateScoresButton.Size = new Size(133, 23);
            calculateScoresButton.TabIndex = 14;
            calculateScoresButton.Text = "Calculate Scores";
            toolTip1.SetToolTip(calculateScoresButton, "Press to calculate scores");
            calculateScoresButton.UseVisualStyleBackColor = false;
            calculateScoresButton.Click += calculateScoresButton_Click;
            // 
            // closeButton
            // 
            closeButton.FlatStyle = FlatStyle.System;
            closeButton.Location = new Point(535, 451);
            closeButton.Name = "closeButton";
            closeButton.Size = new Size(82, 23);
            closeButton.TabIndex = 16;
            closeButton.Text = "Close";
            toolTip1.SetToolTip(closeButton, "Press to close application");
            closeButton.UseVisualStyleBackColor = true;
            closeButton.Click += closeButton_Click;
            // 
            // clearScoresButton
            // 
            clearScoresButton.FlatStyle = FlatStyle.System;
            clearScoresButton.Location = new Point(192, 451);
            clearScoresButton.Name = "clearScoresButton";
            clearScoresButton.Size = new Size(117, 23);
            clearScoresButton.TabIndex = 15;
            clearScoresButton.Text = "&Clear Scores";
            toolTip1.SetToolTip(clearScoresButton, "Press to clear all scores");
            clearScoresButton.UseVisualStyleBackColor = true;
            clearScoresButton.Click += clearScoresButton_Click;
            // 
            // examTotalLabel
            // 
            examTotalLabel.AutoSize = true;
            examTotalLabel.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            examTotalLabel.Location = new Point(192, 343);
            examTotalLabel.Name = "examTotalLabel";
            examTotalLabel.Size = new Size(76, 15);
            examTotalLabel.TabIndex = 33;
            examTotalLabel.Text = "Exam Total : ";
            // 
            // examTotalResultLabel
            // 
            examTotalResultLabel.AutoSize = true;
            examTotalResultLabel.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            examTotalResultLabel.Location = new Point(292, 343);
            examTotalResultLabel.Name = "examTotalResultLabel";
            examTotalResultLabel.Size = new Size(0, 15);
            examTotalResultLabel.TabIndex = 34;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            label6.Location = new Point(354, 343);
            label6.Name = "label6";
            label6.Size = new Size(67, 15);
            label6.TabIndex = 33;
            label6.Text = "Lab Total : ";
            // 
            // labTotalResultLabel
            // 
            labTotalResultLabel.AutoSize = true;
            labTotalResultLabel.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            labTotalResultLabel.Location = new Point(454, 343);
            labTotalResultLabel.Name = "labTotalResultLabel";
            labTotalResultLabel.Size = new Size(0, 15);
            labTotalResultLabel.TabIndex = 34;
            // 
            // quizTotalLabel
            // 
            quizTotalLabel.AutoSize = true;
            quizTotalLabel.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            quizTotalLabel.Location = new Point(517, 343);
            quizTotalLabel.Name = "quizTotalLabel";
            quizTotalLabel.Size = new Size(74, 15);
            quizTotalLabel.TabIndex = 33;
            quizTotalLabel.Text = "Quiz Total : ";
            // 
            // quizTotalResultLabel
            // 
            quizTotalResultLabel.AutoSize = true;
            quizTotalResultLabel.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            quizTotalResultLabel.Location = new Point(617, 343);
            quizTotalResultLabel.Name = "quizTotalResultLabel";
            quizTotalResultLabel.Size = new Size(0, 15);
            quizTotalResultLabel.TabIndex = 34;
            // 
            // finalLetterGradeLabel
            // 
            finalLetterGradeLabel.AutoSize = true;
            finalLetterGradeLabel.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            finalLetterGradeLabel.Location = new Point(307, 394);
            finalLetterGradeLabel.Name = "finalLetterGradeLabel";
            finalLetterGradeLabel.Size = new Size(147, 19);
            finalLetterGradeLabel.TabIndex = 35;
            finalLetterGradeLabel.Text = "Final Letter Grade : ";
            // 
            // finalLetterGradeResult
            // 
            finalLetterGradeResult.AutoSize = true;
            finalLetterGradeResult.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            finalLetterGradeResult.Location = new Point(487, 388);
            finalLetterGradeResult.Name = "finalLetterGradeResult";
            finalLetterGradeResult.Size = new Size(0, 26);
            finalLetterGradeResult.TabIndex = 36;
            // 
            // Form1
            // 
            AcceptButton = calculateScoresButton;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            CancelButton = closeButton;
            ClientSize = new Size(809, 534);
            Controls.Add(finalLetterGradeResult);
            Controls.Add(finalLetterGradeLabel);
            Controls.Add(quizTotalResultLabel);
            Controls.Add(labTotalResultLabel);
            Controls.Add(examTotalResultLabel);
            Controls.Add(quizTotalLabel);
            Controls.Add(label6);
            Controls.Add(examTotalLabel);
            Controls.Add(clearScoresButton);
            Controls.Add(closeButton);
            Controls.Add(calculateScoresButton);
            Controls.Add(label16);
            Controls.Add(label11);
            Controls.Add(quiz5Textbox);
            Controls.Add(lab5Textbox);
            Controls.Add(label15);
            Controls.Add(label10);
            Controls.Add(label5);
            Controls.Add(quiz4Textbox);
            Controls.Add(lab4Textbox);
            Controls.Add(exam4Textbox);
            Controls.Add(label14);
            Controls.Add(label9);
            Controls.Add(label4);
            Controls.Add(quiz3Textbox);
            Controls.Add(lab3Textbox);
            Controls.Add(exam3Textbox);
            Controls.Add(label13);
            Controls.Add(label8);
            Controls.Add(label3);
            Controls.Add(quiz2Textbox);
            Controls.Add(lab2Textbox);
            Controls.Add(exam2Textbox);
            Controls.Add(label12);
            Controls.Add(label7);
            Controls.Add(label2);
            Controls.Add(quiz1Textbox);
            Controls.Add(lab1Textbox);
            Controls.Add(exam1Textbox);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Shawn Conboy Chapter 1 Student Grade Report";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox exam1Textbox;
        private Label label2;
        private TextBox exam2Textbox;
        private Label label3;
        private TextBox exam3Textbox;
        private Label label4;
        private TextBox exam4Textbox;
        private Label label5;
        private TextBox lab1Textbox;
        private Label label7;
        private TextBox lab2Textbox;
        private Label label8;
        private TextBox lab3Textbox;
        private Label label9;
        private TextBox lab4Textbox;
        private Label label10;
        private TextBox lab5Textbox;
        private Label label11;
        private TextBox quiz1Textbox;
        private Label label12;
        private TextBox quiz2Textbox;
        private Label label13;
        private TextBox quiz3Textbox;
        private Label label14;
        private TextBox quiz4Textbox;
        private Label label15;
        private TextBox quiz5Textbox;
        private Label label16;
        private Button calculateScoresButton;
        private ToolTip toolTip1;
        private Button closeButton;
        private Button clearScoresButton;
        private Label examTotalLabel;
        private Label examTotalResultLabel;
        private Label label6;
        private Label labTotalResultLabel;
        private Label quizTotalLabel;
        private Label quizTotalResultLabel;
        private Label finalLetterGradeLabel;
        private Label finalLetterGradeResult;
    }
}
