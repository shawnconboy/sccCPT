package test1Review;

public class TemperatureChecker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
